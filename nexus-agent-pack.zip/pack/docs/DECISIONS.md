# Decisions Log
(Agent: append one line per assumption or deviation, with date.)
